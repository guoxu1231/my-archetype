package org.stellar.sdk.federation;

public class ConnectionErrorException extends RuntimeException {
}
