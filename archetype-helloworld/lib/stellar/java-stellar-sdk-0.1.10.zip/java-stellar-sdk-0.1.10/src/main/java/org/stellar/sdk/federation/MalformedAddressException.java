package org.stellar.sdk.federation;

/**
 * Given Stellar address is malformed.
 */
public class MalformedAddressException extends RuntimeException {
}
