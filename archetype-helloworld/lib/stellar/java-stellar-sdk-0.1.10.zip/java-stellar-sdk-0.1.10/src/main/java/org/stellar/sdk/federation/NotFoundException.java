package org.stellar.sdk.federation;

/**
 * Stellar address not found by federation server
 */
public class NotFoundException extends RuntimeException {
}
