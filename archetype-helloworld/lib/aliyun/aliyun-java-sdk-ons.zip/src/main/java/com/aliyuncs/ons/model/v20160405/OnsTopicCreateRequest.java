/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.aliyuncs.ons.model.v20160405;

import com.aliyuncs.RpcAcsRequest;

/**
 * @author auto create
 * @version 
 */
public class OnsTopicCreateRequest extends RpcAcsRequest<OnsTopicCreateResponse> {
	
	public OnsTopicCreateRequest() {
		super("Ons", "2016-04-05", "OnsTopicCreate");
	}

	private String onsRegionId;

	private String onsPlatform;

	private Long preventCache;

	private String topic;

	private String cluster;

	private Integer queueNum;

	private Boolean order;

	private Long qps;

	private Integer status;

	private String remark;

	private String appkey;

	private String appName;

	public String getOnsRegionId() {
		return this.onsRegionId;
	}

	public void setOnsRegionId(String onsRegionId) {
		this.onsRegionId = onsRegionId;
		putQueryParameter("OnsRegionId", onsRegionId);
	}

	public String getOnsPlatform() {
		return this.onsPlatform;
	}

	public void setOnsPlatform(String onsPlatform) {
		this.onsPlatform = onsPlatform;
		putQueryParameter("OnsPlatform", onsPlatform);
	}

	public Long getPreventCache() {
		return this.preventCache;
	}

	public void setPreventCache(Long preventCache) {
		this.preventCache = preventCache;
		putQueryParameter("PreventCache", preventCache);
	}

	public String getTopic() {
		return this.topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
		putQueryParameter("Topic", topic);
	}

	public String getCluster() {
		return this.cluster;
	}

	public void setCluster(String cluster) {
		this.cluster = cluster;
		putQueryParameter("Cluster", cluster);
	}

	public Integer getQueueNum() {
		return this.queueNum;
	}

	public void setQueueNum(Integer queueNum) {
		this.queueNum = queueNum;
		putQueryParameter("QueueNum", queueNum);
	}

	public Boolean getOrder() {
		return this.order;
	}

	public void setOrder(Boolean order) {
		this.order = order;
		putQueryParameter("Order", order);
	}

	public Long getQps() {
		return this.qps;
	}

	public void setQps(Long qps) {
		this.qps = qps;
		putQueryParameter("Qps", qps);
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
		putQueryParameter("Status", status);
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
		putQueryParameter("Remark", remark);
	}

	public String getAppkey() {
		return this.appkey;
	}

	public void setAppkey(String appkey) {
		this.appkey = appkey;
		putQueryParameter("Appkey", appkey);
	}

	public String getAppName() {
		return this.appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
		putQueryParameter("AppName", appName);
	}

	@Override
	public Class<OnsTopicCreateResponse> getResponseClass() {
		return OnsTopicCreateResponse.class;
	}

}
