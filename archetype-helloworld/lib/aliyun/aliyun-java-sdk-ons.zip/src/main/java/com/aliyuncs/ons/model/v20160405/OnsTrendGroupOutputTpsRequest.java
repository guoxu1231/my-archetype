/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package com.aliyuncs.ons.model.v20160405;

import com.aliyuncs.RpcAcsRequest;

/**
 * @author auto create
 * @version 
 */
public class OnsTrendGroupOutputTpsRequest extends RpcAcsRequest<OnsTrendGroupOutputTpsResponse> {
	
	public OnsTrendGroupOutputTpsRequest() {
		super("Ons", "2016-04-05", "OnsTrendGroupOutputTps");
	}

	private String onsRegionId;

	private String onsPlatform;

	private Long preventCache;

	private String consumerId;

	private String topic;

	private Long beginTime;

	private Long endTime;

	private Long period;

	private Integer type;

	public String getOnsRegionId() {
		return this.onsRegionId;
	}

	public void setOnsRegionId(String onsRegionId) {
		this.onsRegionId = onsRegionId;
		putQueryParameter("OnsRegionId", onsRegionId);
	}

	public String getOnsPlatform() {
		return this.onsPlatform;
	}

	public void setOnsPlatform(String onsPlatform) {
		this.onsPlatform = onsPlatform;
		putQueryParameter("OnsPlatform", onsPlatform);
	}

	public Long getPreventCache() {
		return this.preventCache;
	}

	public void setPreventCache(Long preventCache) {
		this.preventCache = preventCache;
		putQueryParameter("PreventCache", preventCache);
	}

	public String getConsumerId() {
		return this.consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
		putQueryParameter("ConsumerId", consumerId);
	}

	public String getTopic() {
		return this.topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
		putQueryParameter("Topic", topic);
	}

	public Long getBeginTime() {
		return this.beginTime;
	}

	public void setBeginTime(Long beginTime) {
		this.beginTime = beginTime;
		putQueryParameter("BeginTime", beginTime);
	}

	public Long getEndTime() {
		return this.endTime;
	}

	public void setEndTime(Long endTime) {
		this.endTime = endTime;
		putQueryParameter("EndTime", endTime);
	}

	public Long getPeriod() {
		return this.period;
	}

	public void setPeriod(Long period) {
		this.period = period;
		putQueryParameter("Period", period);
	}

	public Integer getType() {
		return this.type;
	}

	public void setType(Integer type) {
		this.type = type;
		putQueryParameter("Type", type);
	}

	@Override
	public Class<OnsTrendGroupOutputTpsResponse> getResponseClass() {
		return OnsTrendGroupOutputTpsResponse.class;
	}

}
